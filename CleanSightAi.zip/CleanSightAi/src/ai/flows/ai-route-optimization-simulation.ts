'use server';
/**
 * @fileOverview A Genkit flow for simulating optimized waste collection routes.
 * 
 * Includes a heuristic fallback to handle API quota exhaustion (429 errors).
 *
 * - simulateRouteOptimization - A function that handles the simulation of route optimization.
 * - RouteOptimizationInput - The input type for the simulateRouteOptimization function.
 * - RouteOptimizationOutput - The return type for the simulateRouteOptimization function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const IncidentSchema = z.object({
  id: z.string().describe('Unique identifier for the incident location.'),
  latitude: z.number().describe('The latitude coordinate of the incident.'),
  longitude: z.number().describe('The longitude coordinate of the incident.'),
  severity: z
    .enum(['Low', 'Medium', 'High', 'Critical'])
    .describe('The severity level of the waste incident.'),
});

const RouteOptimizationInputSchema = z.object({
  incidents: z
    .array(IncidentSchema)
    .describe('A list of waste incidents requiring collection.'),
  depotLocation: z
    .object({
      latitude: z.number().describe('The latitude of the collection depot.'),
      longitude: z.number().describe('The longitude of the collection depot.'),
    })
    .describe('The starting and ending location for collection vehicles.'),
  vehicleCapacity: z.number().optional().describe('Optional: The capacity of a collection vehicle.'),
  numVehicles: z.number().optional().describe('Optional: The number of available collection vehicles.'),
});
export type RouteOptimizationInput = z.infer<typeof RouteOptimizationInputSchema>;

const RouteOptimizationOutputSchema = z.object({
  optimizedRoute: z
    .array(z.string())
    .describe('An ordered list of incident IDs representing the optimized collection route.'),
  estimatedFuelSavingsPercentage: z
    .number()
    .describe('The estimated percentage of fuel savings from the optimized route.'),
  estimatedOperationalEfficiencyImprovementPercentage: z
    .number()
    .describe('The estimated percentage improvement in operational efficiency.'),
  routeSummary: z
    .string()
    .describe('A textual summary and explanation of the optimized route.'),
  totalEstimatedDistanceKm: z.number().describe('The total estimated distance of the optimized route in kilometers.'),
  totalEstimatedTimeHours: z.number().describe('The total estimated time for the optimized route in hours.'),
});
export type RouteOptimizationOutput = z.infer<typeof RouteOptimizationOutputSchema>;

export async function simulateRouteOptimization(
  input: RouteOptimizationInput
): Promise<RouteOptimizationOutput> {
  return routeOptimizationFlow(input);
}

const routeOptimizationPrompt = ai.definePrompt({
  name: 'routeOptimizationPrompt',
  input: { schema: RouteOptimizationInputSchema },
  output: { schema: RouteOptimizationOutputSchema },
  prompt: `You are an AI-powered waste management logistics expert. Your task is to simulate and optimize collection routes for waste incidents.

Prioritize incidents based on severity (Critical > High > Medium > Low) and then by geographical proximity to create the most efficient route.

Input Incidents:
{{#each incidents}}
- ID: {{{this.id}}}, Severity: {{{this.severity}}}, Location: (Lat: {{{this.latitude}}}, Lon: {{{this.longitude}}})
{{/each}}

Depot Location: (Lat: {{{depotLocation.latitude}}}, Lon: {{{depotLocation.longitude}}})

Provide the optimized route as an ordered list of incident IDs, followed by the estimated fuel savings percentage, operational efficiency improvement percentage, total estimated distance in kilometers, total estimated time in hours, and a summary explaining your optimization logic.`,
});

const routeOptimizationFlow = ai.defineFlow(
  {
    name: 'routeOptimizationFlow',
    inputSchema: RouteOptimizationInputSchema,
    outputSchema: RouteOptimizationOutputSchema,
  },
  async (input) => {
    try {
      const { output } = await routeOptimizationPrompt(input);
      if (!output) throw new Error('AI output was empty');
      return output;
    } catch (error: any) {
      // Check if the error is a rate limit or quota issue
      const isQuotaError = error.message?.includes('429') || 
                           error.message?.includes('RESOURCE_EXHAUSTED') || 
                           error.message?.includes('quota');

      if (isQuotaError) {
        // FALLBACK: Priority-Based Heuristic Sorting
        // Sort by Priority (Critical first) then roughly by ID for stability
        const priorityRank: Record<string, number> = { 'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3 };
        
        const sortedIncidents = [...input.incidents].sort((a, b) => {
          const rankA = priorityRank[a.severity] ?? 99;
          const rankB = priorityRank[b.severity] ?? 99;
          return rankA - rankB;
        });

        // Calculate a very rough total distance (straight line estimate * 1.4 for road winding)
        let totalDist = 0;
        let lastLat = input.depotLocation.latitude;
        let lastLon = input.depotLocation.longitude;

        for (const inc of sortedIncidents) {
          const d = Math.sqrt(Math.pow(inc.latitude - lastLat, 2) + Math.pow(inc.longitude - lastLon, 2)) * 111; // ~111km per degree
          totalDist += d;
          lastLat = inc.latitude;
          lastLon = inc.longitude;
        }
        
        // Add return to depot
        totalDist += Math.sqrt(Math.pow(input.depotLocation.latitude - lastLat, 2) + Math.pow(input.depotLocation.longitude - lastLon, 2)) * 111;

        return {
          optimizedRoute: sortedIncidents.map(i => i.id),
          estimatedFuelSavingsPercentage: 12,
          estimatedOperationalEfficiencyImprovementPercentage: 15,
          routeSummary: "Calculated using CleanSight Priority-Based Heuristic (AI API currently at capacity). Locations prioritized by severity to minimize environmental impact.",
          totalEstimatedDistanceKm: parseFloat((totalDist * 1.4).toFixed(2)),
          totalEstimatedTimeHours: parseFloat(((totalDist * 1.4) / 40).toFixed(2)) // Assume 40km/h
        };
      }
      
      // Re-throw if it's a different kind of error
      throw error;
    }
  }
);

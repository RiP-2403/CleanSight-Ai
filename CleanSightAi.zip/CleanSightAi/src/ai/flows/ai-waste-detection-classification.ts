'use server';
/**
 * @fileOverview This file implements a Genkit flow for AI-powered waste detection and classification.
 *
 * - aiWasteDetectionAndClassification - A function that detects waste, classifies its type, and assigns a severity score from image inputs.
 * - WasteDetectionInput - The input type for the aiWasteDetectionAndClassification function.
 * - WasteDetectionOutput - The return type for the aiWasteDetectionAndClassification function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const WasteDetectionInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a waste incident, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  description: z
    .string()
    .optional()
    .describe(
      'An optional description provided by the user about the waste incident.'
    ),
});
export type WasteDetectionInput = z.infer<typeof WasteDetectionInputSchema>;

const WasteDetectionOutputSchema = z.object({
  wasteDetected: z
    .boolean()
    .describe('Whether waste is detected in the image.'),
  wasteType: z
    .enum([
      'organic',
      'plastic',
      'paper',
      'glass',
      'metal',
      'electronic',
      'hazardous',
      'mixed',
      'other',
      'unknown',
    ])
    .describe('The classified type of waste detected.'),
  severityScore: z
    .enum(['Low', 'Medium', 'High', 'Critical', 'Unknown'])
    .describe('The severity score of the waste incident, indicating its urgency and impact.'),
  explanation: z
    .string()
    .describe(
      'A detailed explanation for the detection, classification, and severity score, including observations from the image.'
    ),
});
export type WasteDetectionOutput = z.infer<typeof WasteDetectionOutputSchema>;

export async function aiWasteDetectionAndClassification(
  input: WasteDetectionInput
): Promise<WasteDetectionOutput> {
  return wasteDetectionFlow(input);
}

const wasteDetectionPrompt = ai.definePrompt({
  name: 'wasteDetectionPrompt',
  input: { schema: WasteDetectionInputSchema },
  output: { schema: WasteDetectionOutputSchema },
  prompt: `You are an expert waste management AI designed to analyze images for waste incidents.
Your task is to detect the presence of waste, classify its type, and assign a severity score.

Here is the information you have:
{{#if description}}Description: {{{description}}}{{/if}}
Photo: {{media url=photoDataUri}}

Perform the following steps:
1. Determine if there is any waste detected in the provided image.
2. If waste is detected, classify its primary type from the following categories: 'organic', 'plastic', 'paper', 'glass', 'metal', 'electronic', 'hazardous', 'mixed', 'other'. If classification is not possible, use 'unknown'.
3. Assign a severity score to the incident based on the amount, type, and potential impact of the waste. Use one of the following scores: 'Low', 'Medium', 'High', 'Critical'. If waste is not detected, use 'Unknown'.
4. Provide a detailed explanation for your findings, including why you assigned the specific waste type and severity score.

Respond with a JSON object strictly adhering to the WasteDetectionOutputSchema.`,
});

const wasteDetectionFlow = ai.defineFlow(
  {
    name: 'wasteDetectionFlow',
    inputSchema: WasteDetectionInputSchema,
    outputSchema: WasteDetectionOutputSchema,
  },
  async (input) => {
    const { output } = await wasteDetectionPrompt(input);
    return output!;
  }
);

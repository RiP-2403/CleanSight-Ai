'use server';
/**
 * @fileOverview A Genkit flow for predicting potential bin overflows and identifying future dumping hotspots.
 *
 * - predictOverflowAndHotspots - A function that handles the prediction process.
 * - PredictiveOverflowHotspotInput - The input type for the predictOverflowAndHotspots function.
 * - PredictiveOverflowHotspotOutput - The return type for the predictOverflowAndHotspots function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const PredictiveOverflowHotspotIncidentSchema = z.object({
  location: z.string().describe('The geographical location of the incident.'),
  incidentType: z.enum(['overflow', 'illegal_dumping']).describe('The type of waste incident.'),
  severity: z.enum(['Low', 'Medium', 'High', 'Critical']).describe('The severity of the incident.'),
  timestamp: z.string().datetime().describe('The ISO 8601 timestamp of when the incident occurred.'),
});

const PredictiveOverflowHotspotCurrentBinStateSchema = z.object({
  binId: z.string().describe('Unique identifier for the bin.'),
  location: z.string().describe('The geographical location of the bin.'),
  fillLevelPercentage: z.number().min(0).max(100).describe('The current fill level of the bin in percentage (0-100).'),
});

const PredictiveOverflowHotspotInputSchema = z.object({
  historicalIncidents: z.array(PredictiveOverflowHotspotIncidentSchema).describe('An array of historical waste management incidents, including location, type, severity, and timestamp.'),
  predictionPeriodDays: z.number().int().positive().describe('The number of days into the future to predict overflows and dumping hotspots.'),
  currentBinStates: z.array(PredictiveOverflowHotspotCurrentBinStateSchema).optional().describe('Optional: Current fill levels for known bins to aid in overflow prediction.'),
});
export type PredictiveOverflowHotspotInput = z.infer<typeof PredictiveOverflowHotspotInputSchema>;

const PredictiveOverflowHotspotOutputSchema = z.object({
  overflowPredictions: z.array(z.object({
    location: z.string().describe('The geographical location of the bin predicted to overflow.'),
    binId: z.string().optional().describe('Unique identifier for the bin, if available.'),
    probability: z.number().min(0).max(1).describe('The probability (0-1) of this bin overflowing.'),
    predictedTimeframe: z.string().describe('The estimated timeframe for the overflow, e.g., "within 24 hours", "in 2-3 days".'),
  })).describe('A list of predicted bin overflows with their probability and estimated timeframe.'),
  dumpingHotspotPredictions: z.array(z.object({
    location: z.string().describe('The geographical location predicted to be an illegal dumping hotspot.'),
    probability: z.number().min(0).max(1).describe('The probability (0-1) of this location becoming a dumping hotspot.'),
    contributingFactors: z.array(z.string()).describe('Factors contributing to the prediction, e.g., "historical trend", "proximity to commercial area", "lack of surveillance".'),
  })).describe('A list of predicted illegal dumping hotspots with their probability and contributing factors.'),
  overallSummary: z.string().describe('An overall summary of the predictions, key insights, and recommendations.'),
});
export type PredictiveOverflowHotspotOutput = z.infer<typeof PredictiveOverflowHotspotOutputSchema>;

export async function predictOverflowAndHotspots(input: PredictiveOverflowHotspotInput): Promise<PredictiveOverflowHotspotOutput> {
  return predictiveOverflowHotspotFlow(input);
}

const predictiveOverflowHotspotPrompt = ai.definePrompt({
  name: 'predictiveOverflowHotspotPrompt',
  input: { schema: PredictiveOverflowHotspotInputSchema },
  output: { schema: PredictiveOverflowHotspotOutputSchema },
  prompt: `You are an advanced AI predictive analytics engine for urban waste management, named CleanSight AI.
Your task is to analyze historical waste incident data and current bin fill levels (if provided) to predict potential bin overflows and identify future illegal dumping hotspots within a specified timeframe.

Carefully analyze the provided data:

Historical Incidents:
{{#each historicalIncidents}}
- Location: {{{this.location}}}, Type: {{{this.incidentType}}}, Severity: {{{this.severity}}}, Timestamp: {{{this.timestamp}}}
{{/each}}

Prediction Period: {{predictionPeriodDays}} days into the future.

{{#if currentBinStates}}
Current Bin States:
{{#each currentBinStates}}
- Bin ID: {{{this.binId}}}, Location: {{{this.location}}}, Fill Level: {{{this.fillLevelPercentage}}}%
{{/each}}
{{/if}}

Based on this information, provide:
1.  A list of predicted bin overflows, including location, bin ID (if available), probability (0-1), and the estimated timeframe for the overflow.
2.  A list of predicted illegal dumping hotspots, including location, probability (0-1), and specific contributing factors that led to this prediction.
3.  An overall summary of your findings, highlighting critical predictions and offering actionable insights or recommendations for proactive resource allocation.

Consider factors like:
-   Frequency and severity of past incidents at specific locations.
-   Proximity to residential/commercial areas, parks, or unmonitored zones for dumping.
-   Trends in fill levels for bins (if currentBinStates are provided).
-   Temporal patterns (e.g., incidents increase on weekends or after holidays).

Respond strictly in JSON format according to the output schema. Ensure probabilities are between 0 and 1.`,
});

const predictiveOverflowHotspotFlow = ai.defineFlow(
  {
    name: 'predictiveOverflowHotspotFlow',
    inputSchema: PredictiveOverflowHotspotInputSchema,
    outputSchema: PredictiveOverflowHotspotOutputSchema,
  },
  async (input) => {
    const { output } = await predictiveOverflowHotspotPrompt(input);
    if (!output) {
      throw new Error('Failed to get a valid prediction output.');
    }
    return output;
  }
);
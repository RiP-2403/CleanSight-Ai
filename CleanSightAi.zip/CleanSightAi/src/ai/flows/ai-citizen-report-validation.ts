'use server';
/**
 * @fileOverview This file implements a Genkit flow to validate if an uploaded image contains waste.
 *
 * - validateCitizenReport - A function that handles the waste detection process in an image.
 * - ValidateCitizenReportInput - The input type for the validateCitizenReport function.
 * - ValidateCitizenReportOutput - The return type for the validateCitizenReport function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ValidateCitizenReportInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "A photo of a potential waste incident, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type ValidateCitizenReportInput = z.infer<typeof ValidateCitizenReportInputSchema>;

const ValidateCitizenReportOutputSchema = z.object({
  isWastePresent: z.boolean().describe('Whether or not waste is detected in the image.'),
  confidence: z
    .number()
    .describe('A confidence score (0-1) indicating the certainty of waste detection.'),
  description: z
    .string()
    .describe('A brief description of what was detected in the image.'),
});
export type ValidateCitizenReportOutput = z.infer<typeof ValidateCitizenReportOutputSchema>;

export async function validateCitizenReport(
  input: ValidateCitizenReportInput
): Promise<ValidateCitizenReportOutput> {
  return validateCitizenReportFlow(input);
}

const prompt = ai.definePrompt({
  name: 'validateCitizenReportPrompt',
  input: {schema: ValidateCitizenReportInputSchema},
  output: {schema: ValidateCitizenReportOutputSchema},
  prompt: `You are an AI assistant specialized in waste detection and classification.

Analyze the provided image to determine if there is any visible waste, such as garbage piles or overflowing bins. Respond with a boolean indicating if waste is present, a confidence score (between 0 and 1) for your assessment, and a brief description of what you observed.

Image: {{media url=imageDataUri}}`,
});

const validateCitizenReportFlow = ai.defineFlow(
  {
    name: 'validateCitizenReportFlow',
    inputSchema: ValidateCitizenReportInputSchema,
    outputSchema: ValidateCitizenReportOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

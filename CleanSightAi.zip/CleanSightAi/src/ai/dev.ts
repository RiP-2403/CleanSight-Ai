import { config } from 'dotenv';
config();

import '@/ai/flows/ai-citizen-report-validation.ts';
import '@/ai/flows/ai-waste-detection-classification.ts';
import '@/ai/flows/ai-route-optimization-simulation.ts';
import '@/ai/flows/predictive-overflow-hotspot.ts';

"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { 
  TrendingUp, 
  Truck, 
  PlusCircle, 
  Search,
  LayoutDashboard,
  Trophy,
  Command,
  ArrowRight,
  History,
  Sparkles
} from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

const navItems = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Predictions", href: "/predictions", icon: TrendingUp },
  { name: "Route Planner", href: "/routes", icon: Truck },
  { name: "Rewards", href: "/rewards", icon: Trophy },
];

const suggestions = [
  { name: "Report a dump site", href: "/report", icon: PlusCircle, category: "Action" },
  { name: "Check bin predictions", href: "/predictions", icon: TrendingUp, category: "Analysis" },
  { name: "Optimize truck routes", href: "/routes", icon: Truck, category: "Logistics" },
  { name: "View leaderboard", href: "/rewards", icon: Trophy, category: "Community" },
  { name: "Contact support", href: "/contact", icon: History, category: "Support" },
];

export function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const logoImg = PlaceHolderImages.find(img => img.id === "app-logo");

  const filteredSuggestions = suggestions.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleNavigate = (href: string) => {
    setIsSearchOpen(false);
    setSearchQuery("");
    router.push(href);
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <div className="relative w-10 h-10 overflow-hidden rounded-md">
              <Image 
                src={logoImg?.imageUrl || ""} 
                alt="CleanSight AI Logo" 
                fill 
                className="object-cover"
                data-ai-hint="eye technology"
              />
            </div>
            <span className="font-headline font-bold text-xl tracking-tight hidden sm:inline-block">
              CleanSight <span className="text-secondary">AI</span>
            </span>
          </Link>
          
          <div className="hidden md:flex ml-10 space-x-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 text-sm font-medium transition-colors hover:text-primary",
                  pathname === item.href ? "text-primary border-b-2 border-primary rounded-none" : "text-muted-foreground"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Link href="/report">
            <button className="hidden sm:flex items-center gap-2 bg-secondary text-secondary-foreground hover:bg-secondary/90 px-4 py-2 rounded-full text-sm font-semibold transition-all shadow-sm">
              <PlusCircle className="w-4 h-4" />
              Report Incident
            </button>
            <button className="sm:hidden p-2 bg-secondary text-secondary-foreground rounded-full">
              <PlusCircle className="w-5 h-5" />
            </button>
          </Link>
          
          <div className="w-px h-6 bg-border" />
          
          <Dialog open={isSearchOpen} onOpenChange={setIsSearchOpen}>
            <DialogTrigger asChild>
              <button className="p-2 hover:bg-muted rounded-full transition-colors group">
                <Search className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
              </button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px] p-0 overflow-hidden border-none shadow-2xl">
              <DialogHeader className="p-6 bg-primary text-white">
                <DialogTitle className="flex items-center gap-2 text-xl">
                  <Command className="w-5 h-5" />
                  Quick Search
                </DialogTitle>
              </DialogHeader>
              <div className="p-4 space-y-4 bg-background">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search tools, pages, or actions..." 
                    className="pl-10 h-12 text-lg focus-visible:ring-primary"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    autoFocus
                  />
                </div>
                
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-2 flex items-center gap-2">
                    <Sparkles className="w-3 h-3" />
                    {searchQuery ? "Search Results" : "Quick Suggestions"}
                  </h4>
                  <div className="grid gap-1">
                    {filteredSuggestions.length > 0 ? (
                      filteredSuggestions.map((item) => (
                        <button
                          key={item.href}
                          onClick={() => handleNavigate(item.href)}
                          className="flex items-center justify-between w-full p-3 rounded-xl hover:bg-primary/5 group transition-colors text-left"
                        >
                          <div className="flex items-center gap-3">
                            <div className="bg-muted p-2 rounded-lg group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                              <item.icon className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="text-sm font-bold">{item.name}</div>
                              <div className="text-[10px] text-muted-foreground uppercase">{item.category}</div>
                            </div>
                          </div>
                          <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                        </button>
                      ))
                    ) : (
                      <div className="p-8 text-center text-muted-foreground italic text-sm">
                        No results found for "{searchQuery}"
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="p-3 bg-muted/30 border-t text-[10px] text-center text-muted-foreground font-medium">
                Tip: Press <kbd className="bg-white border px-1 rounded shadow-sm font-mono font-bold">ESC</kbd> to close search.
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </nav>
  );
}

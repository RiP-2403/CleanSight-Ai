'use client';

import React, { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap, useMapEvents } from 'react-leaflet';
import type { RouteOptimizationOutput } from '@/ai/flows/ai-route-optimization-simulation';

/**
 * Component to handle map centering and resizing.
 */
function MapController({ center }: { center: [number, number] }) {
  const map = useMap();
  
  useEffect(() => {
    if (!map) return;
    map.setView(center, 13);
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 100);
    return () => clearTimeout(timer);
  }, [center, map]);
  
  return null;
}

/**
 * Component to handle map clicks for picking a location.
 */
function MapClickHandler({ onMapClick }: { onMapClick?: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      if (onMapClick) {
        onMapClick(e.latlng.lat, e.latlng.lng);
      }
    },
  });
  return null;
}

interface Incident {
  id: string;
  latitude: number;
  longitude: number;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  locationName?: string;
  city?: string;
}

interface LeafletMapProps {
  center: [number, number];
  routeData?: RouteOptimizationOutput | null;
  selectedCity: string;
  incidents?: Incident[];
  onMapClick?: (lat: number, lng: number) => void;
  pickerCoords?: { lat: number; lng: number } | null;
  showDepot?: boolean;
}

export default function LeafletMap({ 
  center, 
  routeData = null, 
  selectedCity, 
  incidents = [], 
  onMapClick,
  pickerCoords = null,
  showDepot = true
}: LeafletMapProps) {
  const [isMounted, setIsMounted] = useState(false);
  const [L, setL] = useState<any>(null);
  const [roadPath, setRoadPath] = useState<[number, number][]>([]);
  const [isRouting, setIsRouting] = useState(false);

  useEffect(() => {
    import('leaflet').then((Leaflet) => {
      setL(Leaflet.default || Leaflet);
      setIsMounted(true);
    });
  }, []);

  const depotLocation: [number, number] = center;

  // Fetch actual driving directions from OSRM when route data is updated
  const lat = center[0];
  const lng = center[1];

  useEffect(() => {
    if (!routeData || !incidents.length) {
      if (roadPath.length > 0) {
        setRoadPath([]);
      }
      return;
    }

    const fetchRoute = async () => {
      setIsRouting(true);
      try {
        const stops = routeData.optimizedRoute.map(id => {
          const inc = incidents.find(i => i.id === id);
          return inc ? [inc.longitude, inc.latitude] : null;
        }).filter(Boolean);

        const allCoords = [
          [lng, lat], 
          ...stops as number[][],
          [lng, lat]  
        ];

        const coordString = allCoords.map(c => c.join(',')).join(';');
        const url = `https://router.project-osrm.org/route/v1/driving/${coordString}?overview=full&geometries=geojson`;

        const response = await fetch(url);
        const data = await response.json();

        if (data.code === 'Ok' && data.routes && data.routes[0]) {
          const coordinates = data.routes[0].geometry.coordinates.map((c: number[]) => [c[1], c[0]]);
          setRoadPath(coordinates);
        }
      } catch (error) {
        console.error("OSRM Routing failed:", error);
      } finally {
        setIsRouting(false);
      }
    };

    fetchRoute();
  }, [routeData, incidents, lat, lng]);

  const icons = useMemo(() => {
    if (!L) return null;
    
    return {
      custom: (priority: string) => {
        let color = '#22c55e'; 
        if (priority === 'Critical') color = '#ef4444'; 
        else if (priority === 'High') color = '#f97316'; 
        else if (priority === 'Medium') color = '#eab308'; 

        return L.divIcon({
          className: 'custom-icon',
          html: `<div style="background-color: ${color}; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 10px;"></div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });
      },
      depot: L.divIcon({
        className: 'depot-icon',
        html: `<div style="background-color: #10b981; width: 32px; height: 32px; border-radius: 8px; border: 3px solid white; box-shadow: 0 4px 6px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center;"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg></div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      }),
      picker: L.divIcon({
        className: 'picker-icon',
        html: `<div style="color: #ef4444;"><svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
      })
    };
  }, [L]);

  if (!isMounted || !L || !icons) {
    return (
      <div className="w-full h-full bg-muted animate-pulse flex flex-col items-center justify-center text-muted-foreground gap-2">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-bold uppercase tracking-widest">Initializing Map...</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full min-h-[400px]">
      <MapContainer 
        center={center} 
        zoom={13} 
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapController center={center} />
        <MapClickHandler onMapClick={onMapClick} />
        
        {/* Depot / Center Marker */}
        {showDepot && (
          <Marker position={depotLocation} icon={icons.depot}>
            <Popup>
              <div className="font-bold text-primary">Center</div>
              <div className="text-xs text-muted-foreground">{selectedCity}</div>
            </Popup>
          </Marker>
        )}

        {/* Existing Incidents (if any) */}
        {incidents.map((inc) => (
          <Marker 
            key={inc.id} 
            position={[inc.latitude, inc.longitude]} 
            icon={icons.custom(inc.priority)}
          >
            <Popup>
              <div className="font-bold">{inc.priority} Priority Incident</div>
              <div className="text-xs">{inc.locationName || inc.id}</div>
            </Popup>
          </Marker>
        ))}

        {/* Dropped Pin / Picker Marker */}
        {pickerCoords && (
          <Marker position={[pickerCoords.lat, pickerCoords.lng]} icon={icons.picker}>
            <Popup>
              <div className="text-xs font-bold">Reported Location</div>
            </Popup>
          </Marker>
        )}

        {isRouting && (
          <div className="absolute top-4 right-4 z-[1000] bg-white p-2 rounded shadow-md flex items-center gap-2">
            <div className="w-3 h-3 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <span className="text-[10px] font-bold">Calculating Roads...</span>
          </div>
        )}

        {roadPath.length > 0 && (
          <Polyline 
            positions={roadPath} 
            pathOptions={{ 
              color: 'red', 
              weight: 5, 
              opacity: 0.7,
              lineCap: 'round',
              lineJoin: 'round',
              dashArray: '1, 10'
            }} 
          />
        )}
      </MapContainer>
    </div>
  );
}

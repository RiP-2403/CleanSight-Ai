export const firebaseConfig = {
  "projectId": "studio-6453941495-7b5e0",
  "appId": "1:99246706746:web:1b298a3032c9f4ae506503",
  "apiKey": "AIzaSyA4hVmwBMOqseTMLFPovFmEonseiBoTbcg",
  "authDomain": "studio-6453941495-7b5e0.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "99246706746"
};

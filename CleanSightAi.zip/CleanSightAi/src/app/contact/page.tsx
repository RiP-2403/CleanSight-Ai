"use client";

import { useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Mail, Phone, Clock, Send, Loader2, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useFirebase, initiateAnonymousSignIn, setDocumentNonBlocking } from "@/firebase";
import { doc } from "firebase/firestore";

const contactFormSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
  issueType: z.enum(["Technical Issue", "Report Problem", "Suggestion", "Partnership"], {
    required_error: "Please select an issue type.",
  }),
  message: z.string().min(10, "Message must be at least 10 characters."),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

export default function ContactPage() {
  const { toast } = useToast();
  const { auth, firestore, user, isUserLoading } = useFirebase();

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      message: "",
    },
  });

  // Ensure user is signed in (anonymously) for firestore rules
  useEffect(() => {
    if (!isUserLoading && !user && auth) {
      initiateAnonymousSignIn(auth);
    }
  }, [user, isUserLoading, auth]);

  const onSubmit = async (data: ContactFormValues) => {
    if (!firestore) return;

    const submissionId = crypto.randomUUID();
    const docRef = doc(firestore, "contactSubmissions", submissionId);
    
    const submissionData = {
      ...data,
      id: submissionId,
      submissionDate: new Date().toISOString(),
    };

    // Use non-blocking update pattern as per guidelines
    setDocumentNonBlocking(docRef, submissionData, { merge: true });

    toast({
      title: "Message Sent Successfully",
      description: "We've received your inquiry and will get back to you within 24 hours.",
    });
    
    reset();
  };

  return (
    <div className="flex flex-col min-h-screen bg-muted/20">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12 space-y-4">
            <h1 className="text-4xl lg:text-5xl font-headline font-bold text-primary">We're Here to Help</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Have questions about CleanSight AI? Found an issue or want to collaborate? Our support team is ready to assist you.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-1 space-y-6">
              {[
                { 
                  title: "Email Us", 
                  val: "contact@cleansightai.com", 
                  icon: Mail,
                  desc: "Drop us a line anytime."
                },
                { 
                  title: "Call Us", 
                  val: "+91-9159525825", 
                  icon: Phone,
                  desc: "Available for urgent queries."
                },
                { 
                  title: "Support Hours", 
                  val: "Mon–Sat | 9 AM – 6 PM", 
                  icon: Clock,
                  desc: "Excluding public holidays."
                },
              ].map((item, i) => (
                <Card key={i} className="border-none shadow-soft hover:shadow-md transition-shadow">
                  <CardContent className="p-6 flex items-start gap-4">
                    <div className="bg-primary/10 text-primary p-3 rounded-2xl">
                      <item.icon className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-bold text-sm text-primary uppercase tracking-wider">{item.title}</h4>
                      <p className="font-bold text-foreground">{item.val}</p>
                      <p className="text-xs text-muted-foreground">{item.desc}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}

              <Card className="bg-primary text-white border-none shadow-lg">
                <CardContent className="p-8 space-y-4">
                  <div className="bg-white/20 w-12 h-12 rounded-full flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold">24-Hour Response</h3>
                  <p className="text-sm text-blue-100 leading-relaxed">
                    We aim to respond to all inquiries within 24 hours of submission.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-2">
              <Card className="border-none shadow-xl bg-white overflow-hidden">
                <CardHeader className="bg-primary/5 border-b p-8">
                  <CardTitle className="text-2xl font-headline">Send a Message</CardTitle>
                  <CardDescription>Fill out the form below and our team will get back to you shortly.</CardDescription>
                </CardHeader>
                <form onSubmit={handleSubmit(onSubmit)}>
                  <CardContent className="space-y-6 p-8">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="fullName" className="text-xs font-bold uppercase tracking-wider">Full Name</Label>
                        <Input 
                          id="fullName" 
                          placeholder="Jane Doe" 
                          {...register("fullName")}
                          className={errors.fullName ? "border-destructive" : ""}
                        />
                        {errors.fullName && <p className="text-xs text-destructive font-medium">{errors.fullName.message}</p>}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-xs font-bold uppercase tracking-wider">Email Address</Label>
                        <Input 
                          id="email" 
                          type="email" 
                          placeholder="jane@example.com" 
                          {...register("email")}
                          className={errors.email ? "border-destructive" : ""}
                        />
                        {errors.email && <p className="text-xs text-destructive font-medium">{errors.email.message}</p>}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="issueType" className="text-xs font-bold uppercase tracking-wider">Issue Type</Label>
                      <Select onValueChange={(val) => setValue("issueType", val as any)}>
                        <SelectTrigger className={errors.issueType ? "border-destructive" : ""}>
                          <SelectValue placeholder="What are you contacting us about?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Technical Issue">Technical Issue</SelectItem>
                          <SelectItem value="Report Problem">Report Problem</SelectItem>
                          <SelectItem value="Suggestion">Suggestion</SelectItem>
                          <SelectItem value="Partnership">Partnership</SelectItem>
                        </SelectContent>
                      </Select>
                      {errors.issueType && <p className="text-xs text-destructive font-medium">{errors.issueType.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message" className="text-xs font-bold uppercase tracking-wider">Message</Label>
                      <Textarea 
                        id="message" 
                        placeholder="Please describe your inquiry in detail..." 
                        className={`min-h-[150px] ${errors.message ? "border-destructive" : ""}`}
                        {...register("message")}
                      />
                      {errors.message && <p className="text-xs text-destructive font-medium">{errors.message.message}</p>}
                    </div>
                  </CardContent>
                  <CardFooter className="bg-muted/30 border-t p-8">
                    <Button 
                      type="submit" 
                      disabled={isSubmitting} 
                      className="w-full sm:w-auto font-bold px-10 py-6 text-lg rounded-xl shadow-lg transition-all"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5 mr-2" />
                          Send Inquiry
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

"use client";

import { useState, useRef, useMemo, useEffect } from "react";
import dynamic from "next/dynamic";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Truck, 
  Map as MapIcon, 
  Navigation, 
  Fuel, 
  Timer, 
  Route as RouteIcon,
  CheckCircle,
  Loader2,
  Globe,
  Download,
  Clock,
  Layers,
  AlertTriangle,
  ListOrdered,
  MapPin,
  Sparkles
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { simulateRouteOptimization, RouteOptimizationOutput } from "@/ai/flows/ai-route-optimization-simulation";
import { useToast } from "@/hooks/use-toast";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { useFirebase, useCollection, useMemoFirebase, initiateAnonymousSignIn } from "@/firebase";
import { collection } from "firebase/firestore";

const LeafletMap = dynamic(() => import("@/components/maps/LeafletMap"), { 
  ssr: false,
  loading: () => <div className="w-full h-full bg-muted animate-pulse flex items-center justify-center text-muted-foreground">Loading interactive map...</div>
});

const CITY_COORDS: Record<string, [number, number]> = {
  "Madurai": [9.9252, 78.1198],
  "Chennai": [13.0827, 80.2707],
  "Coimbatore": [11.0168, 76.9558],
  "Trichy": [10.7905, 78.7047]
};

const AVERAGE_SPEED_KMH = 40;
const CLEANUP_MINUTES_PER_STOP = 35; // Average of 30-40 mins

export default function RoutesPage() {
  const { firestore, auth, user, isUserLoading } = useFirebase();
  const [loading, setLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [routeData, setRouteData] = useState<RouteOptimizationOutput | null>(null);
  const [selectedCity, setSelectedCity] = useState("Madurai");
  const reportRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Ensure user is signed in to fetch data
  useEffect(() => {
    if (!isUserLoading && !user && auth) {
      initiateAnonymousSignIn(auth);
    }
  }, [user, isUserLoading, auth]);

  // Fetch real incidents from Firestore
  const incidentsQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return collection(firestore, "wasteIncidents");
  }, [firestore]);

  const { data: rawIncidents, isLoading: isDataLoading } = useCollection(incidentsQuery);

  const cityCenter = useMemo(() => CITY_COORDS[selectedCity] || CITY_COORDS["Madurai"], [selectedCity]);

  // Compute incidents list with a fallback example if empty
  const filteredIncidents = useMemo(() => {
    const dbIncidents = rawIncidents || [];
    const cityIncidents = dbIncidents.filter(inc => inc.city === selectedCity || !inc.city);
    
    // Add a default example incident if none exist for the city to allow immediate testing
    if (cityIncidents.length === 0) {
      return [{
        id: "EX-MAD-001",
        locationName: "Meenakshi Park (Example)",
        latitude: cityCenter[0] + 0.008,
        longitude: cityCenter[1] + 0.008,
        priority: "High",
        city: selectedCity,
        isExample: true
      }];
    }
    return cityIncidents;
  }, [rawIncidents, selectedCity, cityCenter]);

  // Calculate realistic duration based on distance + cleaning time per stop
  const calculatedDurationHours = useMemo(() => {
    if (!routeData) return 0;
    const travelTimeHours = routeData.totalEstimatedDistanceKm / AVERAGE_SPEED_KMH;
    const cleaningTimeHours = (routeData.optimizedRoute.length * CLEANUP_MINUTES_PER_STOP) / 60;
    return travelTimeHours + cleaningTimeHours;
  }, [routeData]);

  const durationFormatted = useMemo(() => {
    const totalMinutes = Math.round(calculatedDurationHours * 60);
    const hrs = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    if (hrs > 0) return `${hrs}h ${mins}m`;
    return `${mins} mins`;
  }, [calculatedDurationHours]);

  const generateRoute = async () => {
    if (filteredIncidents.length === 0) {
      toast({
        variant: "destructive",
        title: "No Data",
        description: "There are no active incidents in this region to optimize.",
      });
      return;
    }

    setLoading(true);
    try {
      const result = await simulateRouteOptimization({
        incidents: filteredIncidents.map(inc => ({
          id: inc.id,
          latitude: inc.latitude,
          longitude: inc.longitude,
          severity: (inc.priority || "Medium") as any
        })),
        depotLocation: { latitude: cityCenter[0], longitude: cityCenter[1] },
        numVehicles: 2,
        vehicleCapacity: 10
      });
      setRouteData(result);
      toast({
        title: "Routes Optimized",
        description: `Successfully calculated optimal path for ${filteredIncidents.length} locations.`,
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Simulation Failed",
        description: "AI could not calculate the route. Please check connection.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleExportPDF = async () => {
    if (!reportRef.current) return;
    
    setIsExporting(true);
    try {
      const element = reportRef.current;
      const canvas = await html2canvas(element, { scale: 2, useCORS: true });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`CleanSight_Route_Plan_${selectedCity}.pdf`);
      toast({ title: "Export Successful" });
    } catch (error) {
      toast({ variant: "destructive", title: "Export Failed" });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-muted/20">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8 space-y-8">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 mb-2">
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border shadow-sm text-xs font-bold text-primary hover:bg-muted transition-colors">
                  <Globe className="w-3 h-3" />
                  Region: {selectedCity}
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {Object.keys(CITY_COORDS).map(city => (
                    <DropdownMenuItem key={city} onClick={() => { setSelectedCity(city); setRouteData(null); }}>
                      {city}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <h1 className="text-3xl font-headline font-bold text-primary">Route Optimization</h1>
            <p className="text-muted-foreground">Real-time pathfinding for waste collection points in {selectedCity}.</p>
          </div>
          <div className="flex gap-4">
            <Button 
              variant="outline"
              onClick={handleExportPDF} 
              disabled={isExporting || !routeData}
              className="bg-white border-primary text-primary rounded-full px-6 py-4 font-bold flex gap-2"
            >
              {isExporting ? <Clock className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
              {isExporting ? "Exporting..." : "Export Report"}
            </Button>
            <Button 
              onClick={generateRoute} 
              disabled={loading || isDataLoading}
              className="bg-primary hover:bg-primary/90 rounded-full px-6 py-4 font-bold flex gap-2 text-white shadow-lg"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Navigation className="w-5 h-5" />}
              {isDataLoading ? "Loading Data..." : "Generate Optimized Routes"}
            </Button>
          </div>
        </header>

        <div ref={reportRef} className="space-y-8">
          <div className="grid lg:grid-cols-4 gap-8">
            <div className="lg:col-span-1 space-y-6">
              <Card className="border-none shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Fuel className="w-5 h-5 text-secondary" />
                    Eco-Impact
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-secondary/5 border border-secondary/20 rounded-xl text-center">
                    <div className="text-4xl font-bold text-secondary">
                      {routeData ? `${routeData.estimatedFuelSavingsPercentage}%` : "—"}
                    </div>
                    <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Fuel Savings</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Timer className="w-5 h-5 text-blue-500" />
                    Est. Duration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{routeData ? durationFormatted : "—"}</div>
                  <div className="text-xs text-muted-foreground uppercase font-bold tracking-widest mt-1">
                    {routeData ? `@ ${AVERAGE_SPEED_KMH} km/h + 35m cleaning/stop` : "Awaiting route..."}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    Incidents found
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{filteredIncidents.length}</div>
                  <div className="text-xs text-muted-foreground uppercase font-bold tracking-widest mt-1">
                    {filteredIncidents.some(i => (i as any).isExample) ? "Includes Example" : "Live from Firestore"}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-3 space-y-8">
              <Card className="border-none shadow-sm min-h-[550px] overflow-hidden bg-white flex flex-col">
                <CardHeader className="border-b bg-white flex flex-row items-center justify-between shrink-0">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <MapIcon className="w-5 h-5 text-primary" />
                      Live Incident Map
                    </CardTitle>
                    <CardDescription>Visualizing dump locations with real-time Firestore updates.</CardDescription>
                  </div>
                </CardHeader>
                
                <CardContent className="p-0 relative flex-1">
                  <div id="map" className="w-full h-[500px] rounded-xl overflow-hidden relative">
                    <LeafletMap 
                      center={cityCenter} 
                      routeData={routeData} 
                      selectedCity={selectedCity}
                      incidents={filteredIncidents as any}
                    />

                    {(loading || isDataLoading) && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/50 backdrop-blur-sm z-[1000]">
                        <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
                        <p className="font-bold text-primary">Synchronizing with Firestore...</p>
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="bg-muted/10 border-t p-4 flex items-center justify-between text-xs text-muted-foreground italic">
                  <div className="flex items-center gap-2">
                    <Layers className="w-3 h-3" />
                    OpenStreetMap • Firestore Integrated
                  </div>
                  {routeData && (
                    <div className="flex items-center gap-2 font-bold text-primary">
                      <RouteIcon className="w-3 h-3" />
                      Total Path: {routeData.totalEstimatedDistanceKm} km
                    </div>
                  )}
                </CardFooter>
              </Card>
            </div>
          </div>

          {/* Priority List Table */}
          {routeData && (
            <Card className="border-none shadow-lg bg-white overflow-hidden">
              <CardHeader className="bg-primary/5 border-b">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-xl flex items-center gap-2 text-primary">
                      <ListOrdered className="w-5 h-5" />
                      Optimized Dispatch Priority List
                    </CardTitle>
                    <CardDescription>Ordered sequence of incidents for the collection fleet.</CardDescription>
                  </div>
                  <div className="bg-white px-4 py-2 rounded-lg border shadow-sm flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-xs font-bold text-muted-foreground">AI SEQUENCE VERIFIED</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50 hover:bg-muted/50">
                      <TableHead className="w-[80px] font-bold">Order</TableHead>
                      <TableHead className="font-bold">Incident ID</TableHead>
                      <TableHead className="font-bold">Location Details</TableHead>
                      <TableHead className="font-bold">Priority Level</TableHead>
                      <TableHead className="font-bold">Coordinates</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {routeData.optimizedRoute.map((incidentId, index) => {
                      const incident = filteredIncidents.find(inc => inc.id === incidentId);
                      return (
                        <TableRow key={incidentId} className="hover:bg-primary/5 transition-colors">
                          <TableCell className="font-bold">
                            <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                              {index + 1}
                            </div>
                          </TableCell>
                          <TableCell className="font-mono text-xs font-bold text-primary flex items-center gap-2">
                            {incidentId}
                            {(incident as any)?.isExample && (
                              <Badge variant="outline" className="text-[9px] h-4 bg-secondary/10 text-secondary border-secondary/30">
                                <Sparkles className="w-2 h-2 mr-1" />
                                EXAMPLE
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <MapPin className="w-3 h-3 text-muted-foreground" />
                              <span className="text-sm font-medium">
                                {incident?.locationName || "Unnamed Site"}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              incident?.priority === 'Critical' ? 'bg-red-100 text-red-700' :
                              incident?.priority === 'High' ? 'bg-orange-100 text-orange-700' :
                              incident?.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-green-100 text-green-700'
                            }`}>
                              {incident?.priority || "Medium"}
                            </span>
                          </TableCell>
                          <TableCell className="text-xs font-mono text-muted-foreground">
                            {incident?.latitude.toFixed(4)}, {incident?.longitude.toFixed(4)}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="bg-muted/5 p-6 border-t">
                <div className="w-full flex flex-col md:flex-row justify-between items-center gap-4">
                  <div className="text-sm text-muted-foreground italic">
                    Note: Dispatchers should communicate this sequence to drivers immediately.
                  </div>
                  <Button 
                    className="bg-primary text-white font-bold rounded-xl px-8 shadow-md"
                    onClick={() => {
                      toast({
                        title: "Itinerary Dispatched",
                        description: "The prioritized collection list has been sent to all active fleet units.",
                      });
                    }}
                  >
                    Confirm Dispatch
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { BrainCircuit, MapPin, BarChart3, Radio, Target, Eye } from "lucide-react";

export default function AboutPage() {
  const howItWorks = [
    {
      title: "AI-Powered Detection",
      desc: "Automatically identifies dump sites and overflowing bins using advanced computer vision.",
      icon: BrainCircuit,
    },
    {
      title: "Surveillance Integration",
      desc: "Leverages multi-source data including drone-based imagery for comprehensive city coverage.",
      icon: Eye,
    },
    {
      title: "Real-Time Tracking",
      desc: "Precise geolocation pinpointing of every reported incident for immediate response.",
      icon: MapPin,
    },
    {
      title: "Priority Management",
      desc: "Intelligent sorting of incidents based on volume and urgency to optimize city resources.",
      icon: BarChart3,
    },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 lg:py-32 bg-primary text-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl lg:text-6xl font-headline font-bold mb-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
              Building Cleaner Cities with AI
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
              CleanSight AI is a smart waste monitoring and management platform designed to help cities identify, prioritize, and eliminate illegal dumping sites efficiently.
            </p>
          </div>
        </section>

        {/* Mission & Vision Section */}
        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-none shadow-soft hover:shadow-lg transition-all duration-300 group">
                <CardContent className="p-10 space-y-4">
                  <div className="bg-primary/10 text-primary w-12 h-12 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Target className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-headline font-bold text-primary">Mission Statement</h2>
                  <p className="text-lg text-muted-foreground italic leading-relaxed">
                    "To make urban cleanliness proactive, not reactive."
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-soft hover:shadow-lg transition-all duration-300 group">
                <CardContent className="p-10 space-y-4">
                  <div className="bg-primary/10 text-primary w-12 h-12 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Radio className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-headline font-bold text-primary">Vision</h2>
                  <p className="text-lg text-muted-foreground italic leading-relaxed">
                    "A future where AI helps maintain sustainable, waste-free cities."
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-headline font-bold text-primary mb-4">How It Works</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Our system bridges the gap between technology and responsibility by empowering municipal authorities and citizens.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {howItWorks.map((v, i) => (
                <Card key={i} className="border-none shadow-sm hover:shadow-md transition-all duration-300 p-6 group">
                  <CardContent className="p-0 space-y-4 text-center">
                    <div className="bg-primary/5 text-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                      <v.icon className="w-8 h-8" />
                    </div>
                    <h3 className="font-bold text-xl">{v.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Impact Section */}
        <section className="py-24 bg-primary/5">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center space-y-8">
              <h2 className="text-3xl font-headline font-bold text-primary">Our Impact</h2>
              <div className="text-lg text-muted-foreground leading-relaxed space-y-6">
                <p>
                  CleanSight AI automatically detects dump sites using artificial intelligence, assigns urgency levels based on waste volume, and guides authorities through optimized cleanup routes.
                </p>
                <p>
                  We believe cleaner environments start with smarter systems. By combining technology with a priority-based waste management system, we ensure that every corner of the city remains monitored and maintained.
                </p>
              </div>
              <div className="pt-8">
                <div className="inline-block bg-white border border-primary/20 px-8 py-4 rounded-full shadow-sm text-primary font-bold">
                  Bridging Technology & Responsibility
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

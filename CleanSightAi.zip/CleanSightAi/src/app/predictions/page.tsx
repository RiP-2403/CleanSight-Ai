"use client";

import { useState, useEffect, useRef } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  PredictiveOverflowHotspotInput, 
  PredictiveOverflowHotspotOutput,
  predictOverflowAndHotspots 
} from "@/ai/flows/predictive-overflow-hotspot";
import { 
  BrainCircuit, 
  Flame, 
  AlertCircle, 
  RefreshCcw, 
  TrendingUp,
  MapPin,
  Download,
  Clock
} from "lucide-react";
import { MOCK_INCIDENTS, MOCK_BINS } from "@/lib/mock-data";
import { useToast } from "@/hooks/use-toast";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

export default function PredictionsPage() {
  const [loading, setLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [results, setResults] = useState<PredictiveOverflowHotspotOutput | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const runPrediction = async () => {
    setLoading(true);
    try {
      const input: PredictiveOverflowHotspotInput = {
        historicalIncidents: MOCK_INCIDENTS.map(inc => ({
          location: inc.location,
          incidentType: 'overflow', // Simplification for mock
          severity: inc.severity as any,
          timestamp: inc.timestamp
        })),
        predictionPeriodDays: 7,
        currentBinStates: MOCK_BINS.map(bin => ({
          binId: bin.id,
          location: bin.location,
          fillLevelPercentage: bin.fillLevel
        }))
      };
      const prediction = await predictOverflowAndHotspots(input);
      setResults(prediction);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runPrediction();
  }, []);

  const handleExportPDF = async () => {
    if (!reportRef.current) return;
    
    setIsExporting(true);
    toast({
      title: "Generating AI Prediction Report",
      description: "Compiling hotspots and overflow forecasts. Please wait...",
    });

    try {
      const element = reportRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: "#f8fafc"
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`CleanSight_AI_Predictions_${new Date().toISOString().split('T')[0]}.pdf`);
      
      toast({
        title: "Export Successful",
        description: "Your detailed prediction report has been downloaded.",
      });
    } catch (error: any) {
      console.error("PDF Export Error:", error);
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "Could not generate PDF. Please try again.",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-muted/20">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8 space-y-8">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-primary text-white p-8 rounded-2xl shadow-lg">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              <BrainCircuit className="w-4 h-4" />
              CleanSight AI Prediction Engine
            </div>
            <h1 className="text-4xl font-headline font-bold">Predictive Intelligence</h1>
            <p className="text-blue-100/80 max-w-xl">Forecasting potential overflow points and illegal dumping zones using advanced time-series analysis.</p>
          </div>
          <div className="flex gap-4">
            <Button 
              variant="outline"
              onClick={handleExportPDF} 
              disabled={isExporting || !results}
              className="bg-white/10 hover:bg-white/20 text-white border-white/20 px-6 py-6 font-bold rounded-xl"
            >
              {isExporting ? <Clock className="w-5 h-5 animate-spin mr-2" /> : <Download className="w-5 h-5 mr-2" />}
              {isExporting ? "Exporting..." : "Export Report"}
            </Button>
            <Button 
              onClick={runPrediction} 
              disabled={loading}
              className="bg-secondary text-secondary-foreground hover:bg-white px-8 py-6 text-lg font-bold rounded-xl transition-all shadow-xl"
            >
              {loading ? <RefreshCcw className="w-5 h-5 animate-spin mr-2" /> : <RefreshCcw className="w-5 h-5 mr-2" />}
              Refresh Predictions
            </Button>
          </div>
        </header>

        <div ref={reportRef} className="grid lg:grid-cols-2 gap-8">
          {/* Overflow Predictions */}
          <Card className="border-none shadow-sm overflow-hidden">
            <CardHeader className="bg-white border-b">
              <CardTitle className="flex items-center gap-2 text-primary">
                <AlertCircle className="w-5 h-5" />
                Bin Overflow Risks
              </CardTitle>
              <CardDescription>Probability of overflow within next 48 hours.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {results?.overflowPredictions.map((pred, i) => (
                <div key={i} className="group p-4 rounded-xl border hover:border-primary/30 hover:bg-primary/5 transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div className="space-y-1">
                      <div className="font-bold text-lg flex items-center gap-2">
                        {pred.location}
                        {pred.probability > 0.8 && <Flame className="w-4 h-4 text-red-500 fill-current" />}
                      </div>
                      <div className="text-xs font-medium text-muted-foreground uppercase tracking-widest">
                        Bin: {pred.binId} • {pred.predictedTimeframe}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{(pred.probability * 100).toFixed(0)}%</div>
                      <div className="text-[10px] font-bold text-muted-foreground uppercase">Risk Score</div>
                    </div>
                  </div>
                  <Progress value={pred.probability * 100} className="h-2" />
                </div>
              ))}
              {!results && loading && (
                <div className="space-y-4 animate-pulse">
                  {[1, 2, 3].map(i => <div key={i} className="h-24 bg-muted rounded-xl" />)}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Hotspot Predictions */}
          <div className="space-y-8">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-600">
                  <TrendingUp className="w-5 h-5" />
                  Dumping Hotspots
                </CardTitle>
                <CardDescription>Projected high-risk illegal dumping locations.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {results?.dumpingHotspotPredictions.map((hot, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 bg-white border rounded-xl">
                    <div className="bg-orange-100 p-3 rounded-full">
                      <MapPin className="w-5 h-5 text-orange-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-bold">{hot.location}</div>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {hot.contributingFactors.map((factor, fi) => (
                          <span key={fi} className="text-[10px] bg-muted px-2 py-0.5 rounded text-muted-foreground font-medium">
                            {factor}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-orange-600">{(hot.probability * 100).toFixed(0)}%</div>
                      <div className="text-[10px] text-muted-foreground">PROBABILITY</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Executive Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm leading-relaxed text-muted-foreground italic">
                  {results?.overallSummary || "Gathering insights from current sanitation metrics..."}
                </p>
                <div className="mt-6 flex gap-4">
                  <div className="flex-1 p-3 bg-white rounded-lg border text-center">
                    <div className="text-2xl font-bold text-primary">3</div>
                    <div className="text-[10px] text-muted-foreground font-bold">CRITICAL ZONES</div>
                  </div>
                  <div className="flex-1 p-3 bg-white rounded-lg border text-center">
                    <div className="text-2xl font-bold text-secondary">20%</div>
                    <div className="text-[10px] text-muted-foreground font-bold">PROJ. EFFICIENCY</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

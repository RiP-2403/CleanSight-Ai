"use client";

import { useState } from "react";
import dynamic from "next/dynamic";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  AlertCircle, 
  Camera, 
  CheckCircle2, 
  Loader2, 
  MapPin, 
  Upload, 
  Crosshair, 
  X,
  Globe,
  Navigation
} from "lucide-react";
import { validateCitizenReport } from "@/ai/flows/ai-citizen-report-validation";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

const LeafletMap = dynamic(() => import("@/components/maps/LeafletMap"), { 
  ssr: false,
  loading: () => <div className="w-full h-full bg-muted animate-pulse flex items-center justify-center text-muted-foreground">Loading interactive map...</div>
});

const TAMIL_NADU_CITIES = [
  { name: "Madurai", lat: 9.9252, lng: 78.1198 },
  { name: "Chennai", lat: 13.0827, lng: 80.2707 },
  { name: "Coimbatore", lat: 11.0168, lng: 76.9558 },
  { name: "Trichy", lat: 10.7905, lng: 78.7047 },
];

export default function ReportPage() {
  const { toast } = useToast();
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [locating, setLocating] = useState(false);
  const [selectedCity, setSelectedCity] = useState(TAMIL_NADU_CITIES[0]);
  const [location, setLocation] = useState("");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [validationResult, setValidationResult] = useState<any>(null);
  const [ticketId, setTicketId] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setValidationResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDetectLocation = () => {
    setLocating(true);
    if (!navigator.geolocation) {
      toast({
        variant: "destructive",
        title: "Not Supported",
        description: "Geolocation is not supported by your browser.",
      });
      setLocating(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setCoords({ lat: latitude, lng: longitude });
        setLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
        setLocating(false);
        toast({
          title: "Location Detected",
          description: "Your coordinates have been successfully captured.",
        });
      },
      () => {
        setLocating(false);
        toast({
          variant: "destructive",
          title: "Detection Failed",
          description: "Could not obtain your location. Please pinpoint on map manually.",
        });
      },
      { enableHighAccuracy: true }
    );
  };

  const handleMapClick = (lat: number, lng: number) => {
    setCoords({ lat, lng });
    setLocation(`${lat.toFixed(4)}, ${lng.toFixed(4)}`);
    
    toast({
      title: "Location Selected",
      description: `Point set at ${lat.toFixed(4)}, ${lng.toFixed(4)}`,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!image) return;

    setLoading(true);
    try {
      const result = await validateCitizenReport({ imageDataUri: image });
      setValidationResult(result);

      if (result.isWastePresent) {
        setTicketId(`TKT-${Math.floor(100000 + Math.random() * 900000)}`);
        toast({
          title: "Report Submitted",
          description: "Our AI successfully validated your report. Thank you!",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Validation Failed",
          description: "No waste detected in the image. Please try again with a clearer photo.",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Something went wrong during validation.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-muted/30">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 text-center space-y-2">
            <h1 className="text-3xl font-headline font-bold text-primary">Report a Waste Incident</h1>
            <p className="text-muted-foreground">Snap a photo and pinpoint the location in your city to help sanitation teams.</p>
          </div>

          {!ticketId ? (
            <div className="grid lg:grid-cols-5 gap-8">
              <div className="lg:col-span-3">
                <Card className="shadow-lg border-none overflow-hidden h-full">
                  <form onSubmit={handleSubmit} className="flex flex-col h-full">
                    <CardHeader className="bg-primary/5 border-b">
                      <CardTitle className="text-xl">Evidence & Details</CardTitle>
                      <CardDescription>Upload clear evidence for AI validation.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6 p-6 flex-1">
                      {/* Image Upload Area */}
                      <div className="space-y-3">
                        <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Evidence Image</Label>
                        <div className={cn(
                          "relative border-2 border-dashed rounded-2xl overflow-hidden transition-all group",
                          image ? "h-64" : "h-48 bg-muted/50 hover:bg-muted/80 cursor-pointer"
                        )}>
                          {!image ? (
                            <label className="flex flex-col items-center justify-center h-full gap-4 cursor-pointer">
                              <div className="bg-white p-3 rounded-full shadow-sm group-hover:scale-110 transition-transform">
                                <Camera className="w-8 h-8 text-primary" />
                              </div>
                              <div className="text-center">
                                <span className="block text-sm font-bold">Upload Waste Evidence</span>
                              </div>
                              <Input 
                                type="file" 
                                accept="image/*" 
                                className="hidden" 
                                onChange={handleImageUpload} 
                                required
                              />
                            </label>
                          ) : (
                            <>
                              <Image src={image} alt="Preview" fill className="object-cover" />
                              <button 
                                type="button"
                                onClick={() => setImage(null)}
                                className="absolute top-4 right-4 bg-white/90 text-primary p-1.5 rounded-full hover:bg-white shadow-lg z-10"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Label htmlFor="description" className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Details (Optional)</Label>
                        <Textarea 
                          id="description" 
                          placeholder="Briefly describe the situation..." 
                          className="min-h-[80px] text-sm"
                        />
                      </div>
                    </CardContent>
                    <CardFooter className="bg-muted/20 border-t p-6">
                      <Button 
                        type="submit" 
                        className="w-full bg-primary py-6 text-lg font-bold rounded-xl shadow-lg"
                        disabled={loading || !image || !location}
                      >
                        {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Upload className="mr-2 h-5 w-5" />}
                        {loading ? "AI Validating..." : "Submit Report"}
                      </Button>
                    </CardFooter>
                  </form>
                </Card>
              </div>

              <div className="lg:col-span-2">
                <Card className="shadow-lg border-none h-full overflow-hidden flex flex-col">
                  <CardHeader className="bg-secondary/10 border-b">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl">Pinpoint Location</CardTitle>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="sm" className="bg-white font-bold h-8">
                            <Globe className="w-3 h-3 mr-2" />
                            {selectedCity.name}
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          {TAMIL_NADU_CITIES.map((city) => (
                            <DropdownMenuItem key={city.name} onClick={() => setSelectedCity(city)}>
                              {city.name}
                            </DropdownMenuItem>
                          ))}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0 flex-1 relative min-h-[400px]">
                    <div className="w-full h-full">
                      <LeafletMap 
                        center={[selectedCity.lat, selectedCity.lng]} 
                        selectedCity={selectedCity.name}
                        onMapClick={handleMapClick}
                        pickerCoords={coords}
                        showDepot={false}
                      />
                    </div>
                    
                    <div className="absolute bottom-4 left-4 right-4 space-y-2 z-[1000]">
                      <Button 
                        variant="secondary" 
                        className="w-full bg-white/90 backdrop-blur shadow-md font-bold text-xs"
                        onClick={handleDetectLocation}
                        disabled={locating}
                      >
                        {locating ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <Crosshair className="w-3 h-3 mr-2" />}
                        Use GPS Coordinates
                      </Button>
                      <div className="bg-white/90 backdrop-blur p-2 rounded border shadow-sm">
                        <div className="text-[10px] font-bold text-muted-foreground uppercase">Current Selection</div>
                        <div className="text-xs truncate font-medium">{location || "Not selected"}</div>
                      </div>
                    </div>
                  </CardContent>
                  <div className="p-4 bg-muted/30 text-[10px] text-muted-foreground italic flex gap-2">
                    <Navigation className="w-3 h-3 shrink-0" />
                    Tip: Select your city above, then click on the map to drop a pin exactly where the waste is located.
                  </div>
                </Card>
              </div>
            </div>
          ) : (
            <Card className="text-center py-12 px-6 shadow-xl border-t-4 border-t-secondary animate-in zoom-in duration-300">
              <CardContent className="space-y-6">
                <div className="w-20 h-20 bg-secondary/10 text-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-12 h-12" />
                </div>
                <h2 className="text-3xl font-headline font-bold">Report Received!</h2>
                <div className="space-y-2">
                  <p className="text-muted-foreground text-lg">Thank you for helping {selectedCity.name} stay clean.</p>
                  <div className="inline-block bg-primary/5 border border-primary/10 px-6 py-3 rounded-xl font-mono text-2xl font-bold tracking-widest text-primary shadow-inner">
                    {ticketId}
                  </div>
                </div>
                
                {validationResult && (
                  <div className="bg-white border-2 border-secondary/20 rounded-2xl p-6 text-left space-y-3 shadow-sm max-w-md mx-auto">
                    <div className="flex items-center gap-2 text-sm font-bold text-secondary uppercase tracking-wider">
                      <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
                      AI Analysis Verified
                    </div>
                    <p className="text-sm italic leading-relaxed text-foreground/80">
                      "{validationResult.description}"
                    </p>
                    <div className="flex justify-between items-center pt-2 border-t text-xs text-muted-foreground font-medium">
                      <span>Verification Confidence</span>
                      <span className="font-bold text-primary">{(validationResult.confidence * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                )}

                <div className="pt-8 flex flex-col sm:flex-row gap-4 justify-center">
                  <Button variant="outline" onClick={() => window.location.reload()} className="rounded-full px-8 py-6 h-auto font-bold border-2">
                    Report Another
                  </Button>
                  <Button asChild className="rounded-full px-8 py-6 h-auto font-bold shadow-md">
                    <a href="/dashboard">View City Map</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

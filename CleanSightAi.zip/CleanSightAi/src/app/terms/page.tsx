import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Gavel, 
  UserCheck, 
  ShieldAlert, 
  Trophy, 
  Scale, 
  Ban, 
  RefreshCcw,
  FileText
} from "lucide-react";

export default function TermsOfServicePage() {
  const lastUpdated = "May 20, 2024";

  const sections = [
    {
      title: "1. Use of Platform",
      icon: UserCheck,
      content: [
        "Submit accurate and genuine reports of waste incidents.",
        "Do not upload harmful, illegal, or misleading content.",
        "Do not attempt to misuse or exploit the AI detection system."
      ]
    },
    {
      title: "2. Account Responsibility",
      icon: ShieldAlert,
      content: [
        "Users are responsible for maintaining the security of their credentials.",
        "You are liable for all activities conducted under your account.",
        "Protect your login information to prevent unauthorized access."
      ]
    },
    {
      title: "3. AI Predictions",
      icon: RefreshCcw,
      content: [
        "AI-generated classifications are automated estimates and may not be 100% accurate.",
        "CleanSight AI is not liable for decisions made solely based on automated AI predictions.",
        "Final verification by municipal authorities is recommended for critical operations."
      ]
    },
    {
      title: "4. Rewards Program",
      icon: Trophy,
      content: [
        "Points are awarded only after successful AI and manual validation.",
        "Fraudulent reporting or system exploitation will result in point forfeiture and account suspension.",
        "Rewards are non-transferable and have no cash value outside the platform."
      ]
    },
    {
      title: "5. Limitation of Liability",
      icon: Scale,
      content: [
        "CleanSight AI is not responsible for service interruptions or downtime.",
        "We are not liable for inaccurate location data provided by device sensors.",
        "We are not responsible for third-party system failures or external data inaccuracies."
      ]
    },
    {
      title: "6. Termination",
      icon: Ban,
      content: [
        "We reserve the right to suspend or terminate accounts that violate these terms.",
        "CleanSight AI may discontinue services or features at its sole discretion."
      ]
    },
    {
      title: "7. Changes to Terms",
      icon: FileText,
      content: [
        "We may update these terms at any time without prior notice.",
        "Continued use of the platform after updates constitutes acceptance of the new terms."
      ]
    }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-muted/20">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <h1 className="text-4xl lg:text-5xl font-headline font-bold text-primary">Terms of Service</h1>
            <p className="text-muted-foreground font-medium">Last Updated: {lastUpdated}</p>
          </div>

          <Card className="border-none shadow-soft bg-white overflow-hidden">
            <CardContent className="p-0">
              <div className="bg-primary/5 p-8 border-b">
                <div className="flex items-start gap-4">
                  <div className="bg-primary text-white p-3 rounded-2xl">
                    <Gavel className="w-6 h-6" />
                  </div>
                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold text-primary">Binding Agreement</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      By accessing and using CleanSight AI, you agree to be bound by the following terms. These conditions ensure a clean and secure platform for all users.
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-8 space-y-12">
                {sections.map((section, idx) => (
                  <section key={idx} className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500" style={{ animationDelay: `${idx * 100}ms` }}>
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <section.icon className="w-5 h-5 text-primary" />
                      </div>
                      <h3 className="text-xl font-headline font-bold text-primary">{section.title}</h3>
                    </div>
                    <ul className="grid gap-3 pl-12">
                      {section.content.map((item, i) => (
                        <li key={i} className="text-muted-foreground leading-relaxed flex items-start gap-3">
                          <span className="bg-primary/20 w-1.5 h-1.5 rounded-full mt-2 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </section>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="text-center pt-8">
            <p className="text-sm text-muted-foreground">
              Questions about our terms? <a href="/contact" className="text-primary font-bold hover:underline">Contact Support</a>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

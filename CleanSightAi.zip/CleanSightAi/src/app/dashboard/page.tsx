"use client";

import { useState, useRef, useEffect, useMemo } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  ComposedChart,
  Legend,
  Label
} from "recharts";
import { 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  TrendingUp,
  Trash2,
  ChevronDown,
  Globe,
  Info,
  BarChart3,
  Download,
  FileText,
  MapPin,
  Navigation,
  Truck,
  Route
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { MOCK_INCIDENTS, MOCK_STATS } from "@/lib/mock-data";
import { useToast } from "@/hooks/use-toast";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { simulateRouteOptimization, RouteOptimizationOutput } from "@/ai/flows/ai-route-optimization-simulation";

const COLORS = ["#1F7EAD", "#4DE6CB", "#f59e0b", "#ef4444", "#a855f7"];

export default function Dashboard() {
  const [selectedCity, setSelectedCity] = useState("Madurai");
  const [isExporting, setIsExporting] = useState(false);
  const [routeData, setRouteData] = useState<RouteOptimizationOutput | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const filteredIncidents = useMemo(() => 
    MOCK_INCIDENTS.filter(inc => inc.city === selectedCity),
    [selectedCity]
  );

  const priorityData = useMemo(() => [
    { name: 'Critical', current: filteredIncidents.filter(i => i.severity === 'Critical').length, predicted: 5 },
    { name: 'High', current: filteredIncidents.filter(i => i.severity === 'High').length, predicted: 12 },
    { name: 'Medium', current: filteredIncidents.filter(i => i.severity === 'Medium').length, predicted: 18 },
    { name: 'Low', current: filteredIncidents.filter(i => i.severity === 'Low').length, predicted: 8 },
  ], [filteredIncidents]);

  useEffect(() => {
    const fetchRoute = async () => {
      const depotCoords = {
        "Madurai": { lat: 9.9350, lng: 78.1500 },
        "Chennai": { lat: 13.0827, lng: 80.2707 },
        "Coimbatore": { lat: 11.0168, lng: 76.9558 },
        "Trichy": { lat: 10.7905, lng: 78.7047 }
      }[selectedCity] || { lat: 9.9350, lng: 78.1500 };

      try {
        const result = await simulateRouteOptimization({
          incidents: filteredIncidents.map(inc => ({
            id: inc.id,
            latitude: inc.lat,
            longitude: inc.lng,
            severity: inc.severity as any
          })),
          depotLocation: { latitude: depotCoords.lat, longitude: depotCoords.lng },
          numVehicles: 2,
          vehicleCapacity: 10
        });
        setRouteData(result);
      } catch (e) {
        console.error("Route prediction failed", e);
      }
    };
    fetchRoute();
  }, [selectedCity, filteredIncidents]);

  const handleExportPDF = async () => {
    if (!reportRef.current) return;
    
    setIsExporting(true);
    toast({
      title: "Generating Comprehensive Report",
      description: "Compiling dashboard, incident logs, and optimized routes. Please wait...",
    });

    try {
      const element = reportRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: "#f8fafc"
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`CleanSight_Full_Report_${selectedCity}_${new Date().toISOString().split('T')[0]}.pdf`);
      
      toast({
        title: "Export Successful",
        description: "Your detailed city sanitation report has been downloaded.",
      });
    } catch (error: any) {
      console.error("PDF Export Error:", error);
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "Could not generate PDF. Please try again.",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-muted/20">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8 space-y-8">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 mb-2">
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border shadow-sm text-xs font-bold text-primary hover:bg-muted transition-colors">
                  <Globe className="w-3 h-3" />
                  City: {selectedCity}
                  <ChevronDown className="w-3 h-3" />
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setSelectedCity("Madurai")}>Madurai</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSelectedCity("Chennai")}>Chennai</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSelectedCity("Coimbatore")}>Coimbatore</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSelectedCity("Trichy")}>Trichy</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <h1 className="text-3xl font-headline font-bold text-primary">Admin Overview: {selectedCity}</h1>
            <p className="text-muted-foreground">Real-time status of sanitation operations in {selectedCity}, Tamil Nadu.</p>
          </div>
          <div className="flex gap-3">
            <div className="bg-white px-4 py-2 rounded-lg border shadow-sm flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-bold text-muted-foreground">LIVE FEED ACTIVE</span>
            </div>
            <Button 
              onClick={handleExportPDF} 
              disabled={isExporting}
              className="bg-primary text-white px-4 py-2 rounded-lg shadow-sm text-sm font-bold flex items-center gap-2"
            >
              {isExporting ? <Clock className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              {isExporting ? "Exporting..." : "Export Full Report"}
            </Button>
          </div>
        </header>

        <div ref={reportRef} className="space-y-8 p-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: "Active Incidents", value: filteredIncidents.length, icon: AlertTriangle, color: "text-orange-500", bg: "bg-orange-100" },
              { label: "Avg. Response", value: MOCK_STATS.avgResponseTime, icon: Clock, color: "text-blue-500", bg: "bg-blue-100" },
              { label: "Daily Resolved", value: "18", icon: CheckCircle2, color: "text-green-500", bg: "bg-green-100" },
              { label: "Waste (24h)", value: MOCK_STATS.totalWasteCollected, icon: Trash2, color: "text-purple-500", bg: "bg-purple-100" },
            ].map((stat, i) => (
              <Card key={i} className="border-none shadow-sm">
                <CardContent className="p-6 flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                    <p className="text-3xl font-bold">{stat.value}</p>
                  </div>
                  <div className={`${stat.bg} ${stat.color} p-3 rounded-2xl`}>
                    <stat.icon className="w-6 h-6" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <Card className="lg:col-span-2 shadow-sm border-none min-h-[550px] flex flex-col">
              <CardHeader className="flex flex-row items-center justify-between bg-white border-b shrink-0">
                <div>
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    Incident Volume: Current vs. AI Forecast
                  </CardTitle>
                  <CardDescription>Comparison of real-time verified reports vs. predictive data for {selectedCity}.</CardDescription>
                </div>
                <div className="flex gap-2">
                  <span className="text-xs bg-secondary/10 text-secondary border border-secondary/20 px-2 py-1 rounded font-bold flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    AI Forecast Active
                  </span>
                </div>
              </CardHeader>
              <CardContent className="p-6 flex-1 bg-white">
                <div className="h-[400px] w-full mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={priorityData} margin={{ top: 20, right: 30, left: 30, bottom: 40 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 12, fontWeight: 600, fill: 'hsl(var(--foreground))' }}
                      >
                        <Label value="Priority Level" offset={-25} position="insideBottom" style={{ fill: 'hsl(var(--muted-foreground))', fontSize: '12px', fontWeight: 600 }} />
                      </XAxis>
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                      >
                        <Label value="Incident Count" angle={-90} position="insideLeft" style={{ textAnchor: 'middle', fill: 'hsl(var(--muted-foreground))', fontSize: '12px', fontWeight: 600 }} />
                      </YAxis>
                      <Tooltip 
                        contentStyle={{ 
                          borderRadius: '12px', 
                          border: '1px solid hsl(var(--border))', 
                          boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                          backgroundColor: 'white'
                        }}
                        cursor={{ fill: 'hsl(var(--muted)/0.3)' }}
                      />
                      <Legend verticalAlign="top" height={36} iconType="circle"/>
                      
                      <Bar 
                        dataKey="current" 
                        name="Current (Verified)" 
                        fill="hsl(var(--primary))" 
                        radius={[4, 4, 0, 0]} 
                        barSize={32}
                      />
                      
                      <Bar 
                        dataKey="predicted" 
                        name="AI Forecasted" 
                        fill="hsl(var(--secondary))" 
                        radius={[4, 4, 0, 0]} 
                        barSize={32}
                      />

                      <Line 
                        type="monotone" 
                        dataKey="predicted" 
                        stroke="hsl(var(--secondary))" 
                        strokeWidth={2} 
                        dot={{ r: 4, fill: 'white', strokeWidth: 2 }}
                        name="Predicted Trend"
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-6 p-4 bg-primary/5 rounded-xl border border-primary/10 flex items-start gap-3">
                  <Info className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-primary">Resource Allocation Insight</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      AI projects a <span className="text-primary font-bold">20% increase in High-priority zones</span> within the next 6 hours.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-8">
              <Card className="shadow-sm border-none bg-white">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Trash2 className="w-4 h-4 text-purple-500" />
                    Waste Composition
                  </CardTitle>
                  <CardDescription>Classification of materials reported.</CardDescription>
                </CardHeader>
                <CardContent className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={MOCK_STATS.typeDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {MOCK_STATS.typeDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="shadow-sm border-none bg-white">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-500" />
                    Response Velocity
                  </CardTitle>
                  <CardDescription>Resolution time vs. report volume.</CardDescription>
                </CardHeader>
                <CardContent className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[
                      { name: '8am', volume: 10, resp: 30 },
                      { name: '10am', volume: 25, resp: 45 },
                      { name: '12pm', volume: 40, resp: 55 },
                      { name: '2pm', volume: 30, resp: 40 },
                      { name: '4pm', volume: 15, resp: 35 },
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="volume" stroke="hsl(var(--primary))" strokeWidth={3} dot={false} />
                      <Line type="monotone" dataKey="resp" stroke="hsl(var(--secondary))" strokeWidth={3} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="border-none shadow-sm bg-white overflow-hidden">
              <CardHeader className="bg-primary/5 border-b">
                <CardTitle className="text-xl flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  Detailed Incident Log: {selectedCity}
                </CardTitle>
                <CardDescription>Active reports and geographical markers.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50 hover:bg-muted/50">
                      <TableHead className="font-bold">ID</TableHead>
                      <TableHead className="font-bold">Location</TableHead>
                      <TableHead className="font-bold">Priority</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredIncidents.length > 0 ? (
                      filteredIncidents.map((incident) => (
                        <TableRow key={incident.id} className="hover:bg-muted/30">
                          <TableCell className="font-mono text-xs font-bold text-primary">{incident.id}</TableCell>
                          <TableCell>
                            <div className="flex flex-col">
                              <span className="font-medium text-xs">{incident.location}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              incident.severity === 'Critical' ? 'bg-red-100 text-red-600' :
                              incident.severity === 'High' ? 'bg-orange-100 text-orange-600' :
                              incident.severity === 'Medium' ? 'bg-blue-100 text-blue-600' :
                              'bg-green-100 text-green-600'
                            }`}>
                              {incident.severity}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center py-8 text-muted-foreground italic">
                          No active incidents.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm bg-white overflow-hidden">
              <CardHeader className="bg-secondary/10 border-b">
                <CardTitle className="text-xl flex items-center gap-2">
                  <Truck className="w-5 h-5 text-secondary" />
                  AI-Optimized Dispatch Itinerary
                </CardTitle>
                <CardDescription>Prioritized collection route in sequence.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {!routeData ? (
                  <div className="p-12 text-center space-y-4">
                    <Navigation className="w-12 h-12 text-muted-foreground/20 mx-auto animate-pulse" />
                    <p className="text-sm text-muted-foreground italic">Calculating optimal path for {selectedCity}...</p>
                  </div>
                ) : (
                  <div className="divide-y">
                    {routeData.optimizedRoute.map((id, i) => {
                      const inc = MOCK_INCIDENTS.find(inc => inc.id === id);
                      return (
                        <div key={id} className="p-4 flex items-center gap-4 hover:bg-muted/30 transition-colors">
                          <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xs">
                            {i + 1}
                          </div>
                          <div className="flex-1">
                            <div className="font-bold text-sm">{id}</div>
                            <div className="text-[10px] text-muted-foreground truncate">{inc?.location || "Collection Point"}</div>
                          </div>
                          <div className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            inc?.severity === 'Critical' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
                          }`}>
                            {inc?.severity || "High"}
                          </div>
                        </div>
                      );
                    })}
                    <div className="p-4 bg-muted/10 border-t">
                      <div className="flex items-center gap-2 text-xs font-bold text-secondary">
                        <Route className="w-3 h-3" />
                        Summary: {routeData.totalEstimatedDistanceKm}km • {routeData.totalEstimatedTimeHours}hrs
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

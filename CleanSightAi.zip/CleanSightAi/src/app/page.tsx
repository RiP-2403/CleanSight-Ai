"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { Navbar } from "@/components/layout/Navbar";
import { 
  ArrowRight, 
  ShieldCheck, 
  Zap, 
  TrendingUp, 
  CircleCheck,
  BrainCircuit,
  Navigation,
  Trophy,
  Gift,
  Coins
} from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { cn } from "@/lib/utils";

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const logoImg = PlaceHolderImages.find(img => img.id === "app-logo");
  
  const slideImages = [
    PlaceHolderImages.find(img => img.id === "hero-image")?.imageUrl || "",
    PlaceHolderImages.find(img => img.id === "trash-1")?.imageUrl || "",
    PlaceHolderImages.find(img => img.id === "trash-2")?.imageUrl || "",
    PlaceHolderImages.find(img => img.id === "waste-overflow")?.imageUrl || "",
  ];

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % slideImages.length);
  }, [slideImages.length]);

  useEffect(() => {
    const timer = setInterval(nextSlide, 6000);
    return () => clearInterval(timer);
  }, [nextSlide]);

  const features = [
    { 
      title: "AI Detection", 
      desc: "Real-time computer vision detection for overflowing bins and illegal dumping.",
      icon: BrainCircuit,
      color: "bg-blue-100 text-blue-600",
      href: "/report"
    },
    { 
      title: "Predictive Analysis", 
      desc: "Forecast potential hot-spots and bin overflows before they happen.",
      icon: TrendingUp,
      color: "bg-green-100 text-green-600",
      href: "/predictions"
    },
    { 
      title: "Route Optimization", 
      desc: "Reduce fuel usage and operational costs with smart truck dispatching.",
      icon: Navigation,
      color: "bg-purple-100 text-purple-600",
      href: "/routes"
    },
    { 
      title: "Citizen Portal", 
      desc: "Empower citizens to report issues directly with instant AI validation.",
      icon: ShieldCheck,
      color: "bg-orange-100 text-orange-600",
      href: "/report"
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Section - Fully Automated Slideshow */}
      <section className="relative py-24 lg:py-40 overflow-hidden bg-black text-white">
        {/* Background Slideshow */}
        <div className="absolute inset-0 z-0">
          {slideImages.map((img, idx) => (
            <div
              key={idx}
              className={cn(
                "absolute inset-0 transition-all duration-1000 ease-in-out",
                idx === currentSlide ? "opacity-60 scale-105" : "opacity-0 scale-100"
              )}
              style={{ transitionDuration: '2500ms' }}
            >
              <Image
                src={img}
                alt={`Slide ${idx + 1}`}
                fill
                className="object-cover"
                priority={idx === 0}
              />
            </div>
          ))}
          {/* Enhanced Gradient Overlays */}
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent z-10" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/20 z-10" />
        </div>

        <div className="container mx-auto px-4 relative z-20">
          <div className="max-w-3xl space-y-8">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full text-secondary font-semibold text-sm animate-in fade-in slide-in-from-left-4 duration-700">
              <Zap className="w-4 h-4" />
              Smart City Sanitation
            </div>
            <h1 className="text-5xl lg:text-7xl font-headline font-bold leading-tight animate-in fade-in slide-in-from-left-6 duration-700 delay-100">
              AI Intelligence for <span className="text-secondary">Cleaner Cities</span>
            </h1>
            <p className="text-xl text-blue-100/90 leading-relaxed max-w-xl animate-in fade-in slide-in-from-left-8 duration-700 delay-200">
              CleanSight AI uses computer vision and predictive analytics to detect, predict, and optimize urban waste management in real-time.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4 animate-in fade-in slide-in-from-left-10 duration-700 delay-300">
              <Link href="/report" className="bg-secondary text-secondary-foreground hover:bg-white hover:text-primary px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-lg group/btn">
                Citizen Reporting Portal
                <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
              </Link>
              <Link href="/dashboard" className="bg-white/10 backdrop-blur-md hover:bg-white/20 border border-white/20 px-8 py-4 rounded-full font-bold text-lg text-center transition-all">
                Admin Dashboard
              </Link>
            </div>
          </div>
        </div>
        
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-secondary/10 rounded-full blur-3xl opacity-30 z-10" />
      </section>

      {/* Features Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-4xl font-headline font-bold text-primary">Powerful Smart City Solutions</h2>
            <p className="text-lg text-muted-foreground">Moving beyond reactive waste management with end-to-end data intelligence.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, i) => (
              <Link key={i} href={feature.href} className="block bg-card p-8 rounded-2xl border hover:shadow-xl transition-all group hover:border-primary/50">
                <div className={`${feature.color} w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
                <div className="mt-4 text-primary font-bold text-sm flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  Launch Tool <ArrowRight className="w-3 h-3" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Rewards Highlight Section */}
      <section className="py-24 bg-primary text-white overflow-hidden relative">
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1 relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4 mt-8">
                  <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
                    <ShieldCheck className="w-10 h-10 text-secondary mb-4" />
                    <h4 className="font-bold text-lg">Top 100 Status</h4>
                    <p className="text-sm text-blue-100/70">Join the elite contributors in our city-wide cleanup.</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
                    <Coins className="w-10 h-10 text-secondary mb-4" />
                    <h4 className="font-bold text-lg">Instant Tokens</h4>
                    <p className="text-sm text-blue-100/70">Redeem points for local transport and market vouchers.</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
                    <Gift className="w-10 h-10 text-secondary mb-4" />
                    <h4 className="font-bold text-lg">Exclusive Perks</h4>
                    <p className="text-sm text-blue-100/70">Unlock early access to city events and discounts.</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
                    <CircleCheck className="w-10 h-10 text-secondary mb-4" />
                    <h4 className="font-bold text-lg">Impact Verified</h4>
                    <p className="text-sm text-blue-100/70">AI-verified reports ensure fair reward distribution.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="order-1 lg:order-2 space-y-8">
              <div className="bg-secondary text-secondary-foreground inline-block px-4 py-1 rounded-full text-sm font-bold uppercase tracking-wider">
                Rewards Program
              </div>
              <h2 className="text-4xl lg:text-5xl font-headline font-bold">Your Reports, <span className="text-secondary">Your Rewards</span></h2>
              <p className="text-xl text-blue-100/80 leading-relaxed">
                We believe in recognizing citizens who help keep our streets clean. Earn points for every valid report you submit and redeem them for local benefits.
              </p>
              <div className="pt-4">
                <Link href="/rewards" className="inline-flex items-center gap-2 bg-white text-primary px-8 py-4 rounded-full font-bold text-lg hover:bg-secondary hover:text-secondary-foreground transition-all shadow-xl">
                  Explore Rewards
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-1/4 w-full h-full bg-secondary/10 rounded-full blur-3xl" />
      </section>

      {/* Footer */}
      <footer className="bg-primary py-16 text-white/80 border-t border-white/10">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="space-y-4 col-span-2">
              <div className="flex items-center gap-2">
                <div className="relative w-10 h-10 overflow-hidden rounded">
                  <Image 
                    src={logoImg?.imageUrl || ""} 
                    alt="CleanSight AI Logo" 
                    fill 
                    className="object-cover"
                  />
                </div>
                <span className="font-headline font-bold text-white text-xl tracking-tight">
                  CleanSight AI
                </span>
              </div>
              <p className="text-sm leading-relaxed max-w-xs">
                CleanSight AI is a smart city initiative leveraging computer vision and data intelligence to build cleaner, more sustainable urban environments.
              </p>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-bold text-white uppercase tracking-wider text-xs">Core Tools</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/report" className="hover:text-secondary transition-colors">Submit Report</Link></li>
                <li><Link href="/dashboard" className="hover:text-secondary transition-colors">Admin Dashboard</Link></li>
                <li><Link href="/predictions" className="hover:text-secondary transition-colors">AI Predictions</Link></li>
                <li><Link href="/routes" className="hover:text-secondary transition-colors">Route Planner</Link></li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-bold text-white uppercase tracking-wider text-xs">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/about" className="hover:text-secondary transition-colors">About Us</Link></li>
                <li><Link href="/rewards" className="hover:text-secondary transition-colors">Rewards Program</Link></li>
                <li><Link href="/contact" className="hover:text-secondary transition-colors">Contact Support</Link></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
            <p>© 2024 CleanSight AI. All rights reserved.</p>
            <div className="flex gap-6">
              <Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

"use client";

import { Navbar } from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import Link from "next/link";
import { 
  Trophy, 
  Gift, 
  Coins, 
  Star, 
  Medal, 
  TrendingUp,
  Camera,
  Upload,
  BrainCircuit,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Zap,
  Trash2
} from "lucide-react";
import { MOCK_REWARDS } from "@/lib/mock-data";

export default function RewardsProgramPage() {
  const steps = [
    {
      title: "Capture",
      desc: "Snap a photo of a dump site or overflowing bin.",
      icon: Camera,
      color: "text-blue-500",
      bg: "bg-blue-50"
    },
    {
      title: "Upload",
      desc: "Submit the report through the citizen portal.",
      icon: Upload,
      color: "text-purple-500",
      bg: "bg-purple-50"
    },
    {
      title: "Verify",
      desc: "Our AI validates and assigns priority levels.",
      icon: BrainCircuit,
      color: "text-secondary",
      bg: "bg-secondary/10"
    },
    {
      title: "Earn",
      desc: "Receive points once the report is validated.",
      icon: Coins,
      color: "text-primary",
      bg: "bg-primary/10"
    }
  ];

  const pointBreakdown = [
    { type: "Small Dump", points: 10, description: "Minor littering or single bag" },
    { type: "Medium Dump", points: 25, description: "Multiple bags or medium debris" },
    { type: "Large Dump", points: 50, description: "Significant accumulation or large objects" },
    { type: "Critical Hazard", points: 100, description: "Hazardous waste or major blockages" }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <Navbar />
      
      <main className="flex-1 pb-20">
        {/* Hero Section */}
        <section className="bg-primary text-white py-20 lg:py-28 relative overflow-hidden">
          <div className="container mx-auto px-4 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-1.5 rounded-full text-secondary font-bold text-sm mb-6">
              <Zap className="w-4 h-4" />
              Impact Rewards Program
            </div>
            <h1 className="text-4xl lg:text-6xl font-headline font-bold mb-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
              Earn Rewards. <span className="text-secondary">Build a Cleaner Community.</span>
            </h1>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
              CleanSight AI encourages citizens to actively participate in maintaining city cleanliness. Your vigilance translates into tangible benefits for you and your neighborhood.
            </p>
          </div>
          <Trophy className="absolute -bottom-12 -right-12 w-96 h-96 text-white/5 rotate-12" />
        </section>

        {/* How It Works Section */}
        <section className="py-24 container mx-auto px-4">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl font-headline font-bold text-primary">How It Works</h2>
            <p className="text-muted-foreground">Transforming responsibility into recognition in four simple steps.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, i) => (
              <div key={i} className="relative group">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className={`${step.bg} ${step.color} w-20 h-20 rounded-3xl flex items-center justify-center transition-transform group-hover:scale-110 group-hover:rotate-3 duration-300 shadow-soft`}>
                    <step.icon className="w-10 h-10" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-xl">{step.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
                  </div>
                </div>
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 -right-4 translate-x-1/2">
                    <ArrowRight className="w-6 h-6 text-muted/30" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        <div className="container mx-auto px-4 grid lg:grid-cols-3 gap-12 mt-12">
          {/* Point Breakdown Table */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="border-none shadow-soft overflow-hidden">
              <CardHeader className="bg-primary/5 border-b">
                <CardTitle className="text-2xl font-headline flex items-center gap-2">
                  <Star className="w-6 h-6 text-orange-500 fill-orange-500" />
                  Earning Potential
                </CardTitle>
                <CardDescription>Points awarded per validated incident type.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/30 hover:bg-muted/30">
                      <TableHead className="font-bold py-4">Incident Category</TableHead>
                      <TableHead className="font-bold">Description</TableHead>
                      <TableHead className="font-bold text-right">Points</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pointBreakdown.map((item, i) => (
                      <TableRow key={i} className="hover:bg-muted/10 transition-colors">
                        <TableCell className="font-bold text-primary">{item.type}</TableCell>
                        <TableCell className="text-muted-foreground text-sm">{item.description}</TableCell>
                        <TableCell className="text-right">
                          <Badge variant="secondary" className="font-bold px-3 py-1">
                            +{item.points} pts
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <div className="grid sm:grid-cols-2 gap-6">
              <Card className="border-none shadow-sm hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Gift className="w-5 h-5 text-secondary" />
                    Redeem Impact
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-3">
                    {[
                      "Digital Certificates of Recognition",
                      "Public Leaderboard Status",
                      "Exclusive Eco-Merchandise",
                      "Community Volunteer Credits"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-primary text-white border-none shadow-lg group overflow-hidden relative">
                <CardContent className="p-8 space-y-4 relative z-10">
                  <h3 className="text-2xl font-headline font-bold">Your Status</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-bold uppercase tracking-wider text-blue-100">
                      <span>Eco-Guardian Level {MOCK_REWARDS.level}</span>
                      <span>{MOCK_REWARDS.userPoints} / {MOCK_REWARDS.nextLevelPoints}</span>
                    </div>
                    <Progress value={(MOCK_REWARDS.userPoints / MOCK_REWARDS.nextLevelPoints) * 100} className="h-2 bg-white/20" />
                  </div>
                  <Button asChild className="w-full bg-secondary text-secondary-foreground hover:bg-white font-bold mt-4 shadow-md transition-all">
                    <Link href="/report">Submit New Report</Link>
                  </Button>
                </CardContent>
                <Medal className="absolute -bottom-6 -right-6 w-32 h-32 text-white/5 rotate-12 transition-transform group-hover:scale-110" />
              </Card>
            </div>
          </div>

          {/* Leaderboard Section */}
          <div className="lg:col-span-1">
            <Card className="border-none shadow-soft sticky top-24">
              <CardHeader className="border-b">
                <CardTitle className="flex items-center gap-2 text-xl font-headline">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  Community Leaders
                </CardTitle>
                <CardDescription>Top environmental contributors this month.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {MOCK_REWARDS.leaderboard.map((user, i) => (
                    <div 
                      key={i} 
                      className={`flex items-center gap-4 p-4 transition-colors ${user.isCurrent ? 'bg-primary/5 border-l-4 border-primary' : 'hover:bg-muted/20'}`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                        i === 0 ? 'bg-yellow-100 text-yellow-700' :
                        i === 1 ? 'bg-gray-100 text-gray-700' :
                        i === 2 ? 'bg-orange-100 text-orange-700' : 'bg-muted text-muted-foreground'
                      }`}>
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold truncate text-sm">{user.name}</div>
                        <div className="text-[10px] text-muted-foreground font-medium uppercase tracking-tight">
                          {user.reports} Verified Reports
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-primary text-sm">{user.points}</div>
                        <div className="text-[9px] text-muted-foreground uppercase font-bold">pts</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="pt-6">
                <Button variant="ghost" className="w-full text-xs font-bold uppercase tracking-widest text-primary hover:bg-primary/5">
                  View All Rankings
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

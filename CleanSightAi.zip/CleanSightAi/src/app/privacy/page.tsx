
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldCheck, Info, Database, Share2, UserCheck, RefreshCcw, Mail } from "lucide-react";

export default function PrivacyPolicyPage() {
  const sections = [
    {
      title: "1. Information We Collect",
      icon: Info,
      content: [
        "Name and email address (for account creation)",
        "Uploaded images of reported dump sites",
        "Geolocation data (for accurate reporting)",
        "Device and browser information",
        "Reward points and activity logs"
      ]
    },
    {
      title: "2. How We Use Your Information",
      icon: RefreshCcw,
      content: [
        "Detect and classify waste sites using AI",
        "Prioritize cleanup operations",
        "Improve platform performance",
        "Maintain leaderboard and reward systems",
        "Respond to support inquiries"
      ]
    },
    {
      title: "3. Data Storage",
      icon: Database,
      content: [
        "All data is securely stored using Firebase services.",
        "We implement reasonable security measures to prevent unauthorized access."
      ]
    },
    {
      title: "4. Data Sharing",
      icon: Share2,
      content: [
        "We do not sell personal information.",
        "Location and dump site data may be shared with municipal authorities for cleanup purposes."
      ]
    },
    {
      title: "5. User Rights",
      icon: UserCheck,
      content: [
        "Request deletion of their account",
        "Request data correction",
        "Contact support regarding privacy concerns"
      ]
    },
    {
      title: "6. Updates to This Policy",
      icon: RefreshCcw,
      content: [
        "We may update this policy periodically. Continued use of the platform constitutes acceptance of changes."
      ]
    }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-muted/20">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <h1 className="text-4xl lg:text-5xl font-headline font-bold text-primary">Privacy Policy</h1>
            <p className="text-muted-foreground font-medium">Effective Date: May 20, 2024</p>
          </div>

          <Card className="border-none shadow-soft p-6 lg:p-10 bg-white">
            <CardContent className="space-y-12">
              <div className="flex items-start gap-4 p-6 bg-primary/5 rounded-2xl border border-primary/10">
                <ShieldCheck className="w-8 h-8 text-primary shrink-0" />
                <p className="text-lg text-foreground/80 leading-relaxed">
                  CleanSight AI respects your privacy and is committed to protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard your data when you use our platform.
                </p>
              </div>

              <div className="grid gap-12">
                {sections.map((section, idx) => (
                  <section key={idx} className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <section.icon className="w-5 h-5 text-primary" />
                      </div>
                      <h2 className="text-2xl font-headline font-bold text-primary">{section.title}</h2>
                    </div>
                    <ul className="grid gap-3 pl-12">
                      {section.content.map((item, i) => (
                        <li key={i} className="text-muted-foreground leading-relaxed list-disc">
                          {item}
                        </li>
                      ))}
                    </ul>
                  </section>
                ))}
              </div>

              <div className="pt-12 border-t text-center space-y-4">
                <h3 className="text-xl font-bold">Contact</h3>
                <p className="text-muted-foreground">For privacy concerns, email:</p>
                <a href="mailto:support@cleansightai.com" className="inline-flex items-center gap-2 text-primary font-bold hover:underline transition-all">
                  <Mail className="w-4 h-4" />
                  support@cleansightai.com
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

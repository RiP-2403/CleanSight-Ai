export const MOCK_INCIDENTS = [
  // Madurai Incidents
  { id: "INC-001", location: "Meenakshi Amman Temple North Tower", type: "mixed", severity: "High", status: "Open", timestamp: "2024-05-20T10:30:00Z", lat: 9.9200, lng: 78.1190, city: "Madurai" },
  { id: "INC-002", location: "Mattuthavani Bus Stand Entrance", type: "organic", severity: "Medium", status: "Assigned", timestamp: "2024-05-20T09:15:00Z", lat: 9.9350, lng: 78.1500, city: "Madurai" },
  { id: "INC-003", location: "Gandhi Museum Road", type: "hazardous", severity: "Critical", status: "Open", timestamp: "2024-05-20T11:00:00Z", lat: 9.9280, lng: 78.1380, city: "Madurai" },
  
  // Chennai Incidents
  { id: "INC-101", location: "Marina Beach Promenade", type: "plastic", severity: "High", status: "Open", timestamp: "2024-05-21T08:00:00Z", lat: 13.0475, lng: 80.2824, city: "Chennai" },
  { id: "INC-102", location: "T. Nagar Ranganathan Street", type: "mixed", severity: "Critical", status: "Open", timestamp: "2024-05-21T10:30:00Z", lat: 13.0334, lng: 80.2316, city: "Chennai" },
  
  // Coimbatore Incidents
  { id: "INC-201", location: "Race Course Road", type: "organic", severity: "Low", status: "Resolved", timestamp: "2024-05-21T09:00:00Z", lat: 11.0007, lng: 76.9745, city: "Coimbatore" },
  { id: "INC-202", location: "RS Puram West", type: "mixed", severity: "Medium", status: "Open", timestamp: "2024-05-21T11:15:00Z", lat: 11.0118, lng: 76.9458, city: "Coimbatore" },
];

export const MOCK_BINS = [
  { id: "BIN-A1", location: "Periyar Bus Stand", fillLevel: 85, lastEmptied: "12h ago", lat: 9.9160, lng: 78.1130 },
  { id: "BIN-B2", location: "Railway Junction South", fillLevel: 42, lastEmptied: "4h ago", lat: 9.9180, lng: 78.1090 },
  { id: "BIN-C3", location: "Simmakkal Market", fillLevel: 98, lastEmptied: "24h ago", lat: 9.9240, lng: 78.1210 },
  { id: "BIN-D4", location: "K Pudur Industrial Estate", fillLevel: 15, lastEmptied: "2h ago", lat: 9.9450, lng: 78.1400 },
];

export const MOCK_STATS = {
  dailyIncidents: 24,
  activeReports: 12,
  avgResponseTime: "45m",
  totalWasteCollected: "1.2 Tons",
  typeDistribution: [
    { name: "Organic", value: 35 },
    { name: "Plastic", value: 25 },
    { name: "Paper", value: 20 },
    { name: "Metal", value: 10 },
    { name: "Other", value: 10 },
  ]
};

export const MOCK_REWARDS = {
  userPoints: 1250,
  level: 4,
  nextLevelPoints: 1500,
  achievements: [
    { id: 1, title: "Eco Warrior", icon: "ShieldCheck", date: "2024-03-12" },
    { id: 2, title: "First Report", icon: "Zap", date: "2024-01-05" },
    { id: 3, title: "Trash Terminator", icon: "Trash2", date: "2024-04-20" },
  ],
  leaderboard: [
    { name: "Sarah J.", points: 4500, reports: 42 },
    { name: "Mike R.", points: 3800, reports: 35 },
    { name: "EcoEnthusiast", points: 3200, reports: 28 },
    { name: "You", points: 1250, reports: 12, isCurrent: true },
    { name: "Alex B.", points: 1100, reports: 10 },
  ],
  redeemables: [
    { id: "r1", title: "TNSTC City Pass", cost: 500, type: "Transport" },
    { id: "r2", title: "₹100 Madurai Market Voucher", cost: 800, type: "Shopping" },
    { id: "r3", title: "Vaigai Tree Plantation", cost: 300, type: "Eco" },
    { id: "r4", title: "Clean Madurai Merch", cost: 1200, type: "Exclusive" },
  ]
};
